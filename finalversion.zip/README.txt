默认使用R-Tree，如果要测试四叉树请把’COMMON.H’中的’ #define USE_RTREE’注释掉
如果要测试扩展要求5，请在R-Tree模式下测试，并根据注释修改’hw6.cpp’中的313, 338行代码。
